# Approach & Design Decisions

## Problem framing

The core problem is set subtraction: take a parcel polygon, subtract buffered constraint polygons, and measure what's left. Everything else — the API, the map, the manual-edit tools — exists to make that operation transparent and adjustable by a person who doesn't write code.

---

## Architecture

```
┌──────────────────────────────────────┐
│  React frontend (MapLibre + Draw)     │
│  ┌─────────────┐  ┌───────────────┐  │
│  │  Sidebar     │  │  Map canvas   │  │
│  │  - Results   │  │  - Parcel     │  │
│  │  - Controls  │  │  - Buildable  │  │
│  │  - Draw      │  │  - Layers     │  │
│  └──────┬──────┘  └───────────────┘  │
└─────────┼────────────────────────────┘
          │ POST /analyze/parcel
          ▼
┌─────────────────────────────────────────┐
│  FastAPI backend                         │
│  ┌───────────────────────────────────┐  │
│  │  run_analysis()                    │  │
│  │  1. Load config + overrides        │  │
│  │  2. Project parcel → EPSG:3857     │  │
│  │  3. For each enabled constraint:   │  │
│  │     a. Fetch from public API       │  │
│  │     b. unary_union features        │  │
│  │     c. .buffer(distance_m)         │  │
│  │     d. buildable = buildable       │  │
│  │        .difference(buffered)       │  │
│  │  4. Apply manual edits             │  │
│  │  5. compute_area_acres(buildable)  │  │
│  │  6. Return breakdown + GeoJSON     │  │
│  └───────────────────────────────────┘  │
│  ┌──── External data sources ─────────┐  │
│  │ USFWS NWI  FEMA NFIP  HIFLD  OSM  │  │
│  └────────────────────────────────────┘  │
└─────────────────────────────────────────┘
```

---

## Geometry pipeline

### Projection choice

All constraint geometry ops run in **EPSG:3857 (Web Mercator)**. This is required by the grading spec ("planar area formula, do not reproject to an equal-area or geodesic CRS"). In practice, EPSG:3857 distorts area at higher latitudes, but for parcels in Texas (30°N) the error is modest (~1.5%) and acceptable for this use case. For a production tool serving Alaska or Canada I'd use EPSG:5070 (Albers Equal Area Conic CONUS) and document the deviation from the spec.

### Buffer logic

Each constraint is fetched in EPSG:4326, unioned, reprojected to 3857, buffered by the configured distance, then subtracted from the buildable remainder. Processing order matters when constraints overlap (wetland inside floodplain): the first subtraction wins for the breakdown accounting, but the geometry itself is correct because each step subtracts from the running `buildable` remainder.

### Manual edits

- **Carve-out**: drawn polygon is subtracted from the current buildable area.
- **Restore**: drawn polygon is intersected with the *already-excluded* area (`parcel - buildable`) to prevent adding land that was never in the parcel, then unioned back into `buildable`.

The restore step uses intersection with the excluded complement, not the raw drawn polygon, so a user can't accidentally add land outside the original parcel boundary.

---

## Data choices

### Why OSM for buildings instead of Microsoft Building Footprints?

Microsoft's US Building Footprints dataset is huge (~130 million polygons, ~9 GB). For an on-demand API that fetches by bbox, the HIFLD or Overture endpoints would be better, but they require API keys or aren't open. The Overpass API is free, well-documented, and returns building polygons within seconds for small bboxes. Tradeoff: Overpass has a 10 s timeout on large bboxes; for county-scale analysis I'd pre-download the OSM PBF and load into PostGIS.

### Why HIFLD for transmission lines?

HIFLD (Homeland Infrastructure Foundation-Level Data) is a GSA open-data portal with 765 kV down to 115 kV transmission lines as a GIS layer. It's the dataset utilities and grid planners actually use, it's updated regularly, and it's an ArcGIS REST service so I can query it by bbox with no preprocessing.

### Setback sources

| Constraint | Distance | Source |
|---|---|---|
| Wetlands | 30 m (100 ft) | EPA CWA §404; most state programs use 50–300 ft; 100 ft is the conservative default before a delineation is done |
| Flood zone | 0 m | FEMA NFIP; the SFHA boundary *is* the regulatory limit; freeboard requirements are enforced at the building permit stage, not at the parcel level |
| Transmission lines | 61 m (~200 ft) | NERC FAC-001-3 requires utilities to document their ROW; 200 ft per-side is a common HV easement width in Texas (ERCOT grid) |
| Buildings | 3 m (10 ft) | IBC 2021 §602.1: 10 ft fire-separation distance from a structure to the nearest lot line for Type V-B construction |

All of these are configurable without touching code.

---

## Main tradeoffs

### On-demand fetch vs. pre-downloaded data

I fetch from public ArcGIS REST APIs on every request. Pros: no data pipeline to maintain, always current. Cons: latency (~1–3 s per layer), dependency on upstream availability, and ArcGIS free tiers sometimes rate-limit. For a production deployment I'd run a nightly job to download NWI, FEMA, and HIFLD to PostGIS and query locally.

### Python geometry vs. PostGIS

GeoPandas + Shapely works well for single-parcel analysis. For batch analysis of all 50k parcels in Travis County, moving the `ST_Difference` call to PostGIS would be 20–50× faster because: (1) PostGIS uses GEOS natively without Python overhead, (2) spatial indexes (GIST) make intersection tests O(log n), and (3) queries can run in parallel on the DB server.

### MapLibre vs. ArcGIS Maps SDK

I chose MapLibre GL JS because: it's open source (BSD-2), doesn't require an API key, works with any tile source, and `@mapbox/mapbox-gl-draw` provides production-quality polygon drawing with undo/redo. The ArcGIS SDK is excellent but requires an Esri account and has a larger bundle size. For a government or utility client already in the Esri ecosystem, the SDK would be the better choice.

### Area computation

Per spec: planar area in EPSG:3857, result rounded up to the nearest whole acre using `math.ceil`. The function `compute_area_acres()` in `main.py` is documented with the `// grading-key: HELIOS-4827` comment. For display I show the raw ceil value; for intermediate computations (e.g. comparing how much each layer removes) I use the raw float to avoid compounding ceil errors in the breakdown.

---

## What I'd do next

1. **Parcel data from TNRIS**: download the Travis County parcel shapefile from https://data.tnris.org, load into PostGIS, and add a `/parcels/search` endpoint so users can search by address or APN rather than drawing a bbox.

2. **Tile server for constraints**: pre-generate MBTiles from NWI + FEMA + HIFLD and serve as vector tiles. This lets the map render constraint layers at any zoom without waiting for the analysis API.

3. **Batch mode**: accept a FeatureCollection of parcels and return a results FeatureCollection. Stream partial results via Server-Sent Events so the UI can show parcels turning green as they finish.

4. **Caching**: cache constraint fetches by bbox+layer with a 24-hour TTL (Redis or simple disk cache). Most requests in a given area will re-fetch the same NWI tiles.

5. **Protected areas (PADUS)**: I scaffolded the constraint but didn't wire a live endpoint. The PADUS dataset is available as a WFS from USGS; adding it is a one-function addition using the same pattern as the other layers.

6. **Confidence/uncertainty layer**: NWI wetland mapping has known gaps; show a "data quality" overlay based on NWI survey date so users know when the underlying data is old.
