# Buildable Land Analysis

A full-stack tool that computes how much of a parcel is actually buildable — once you subtract regulatory setbacks and physical constraints — and shows the result on an interactive map.

---

## Quick Start

### Backend

```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

### Frontend

```bash
cd frontend
npm install
npm start
```

Open **http://localhost:3000**. The app auto-loads a demo analysis of a bbox in Austin, TX.

---

## What's in the box

| Layer | Source | Default buffer | Rationale |
|---|---|---|---|
| Wetlands (NWI) | USFWS via ArcGIS REST | **30 m** | EPA Clean Water Act §404; 30 m ≈ 100 ft standard protective buffer |
| FEMA 100-yr Floodplain | FEMA NFIP MapServer | **0 m** | Regulatory boundary itself is the constraint; no extra buffer |
| HV Transmission Lines | HIFLD open data | **61 m** | NERC FAC-001; ~200 ft (61 m) one-side easement corridor |
| Existing Buildings | OpenStreetMap Overpass | **3 m** | IBC 2021 §602 fire-separation distance; 10 ft minimum |

All distances are configurable in `backend/config.yaml` or via request parameters / map controls — no code edits required.

---

## Adjusting constraints

**Config file (persistent):**
```yaml
# backend/config.yaml
constraints:
  wetlands:
    buffer_m: 30   # ← change this
    enabled: true
```
Restart the backend after editing.

**API parameters (per-request):**
```bash
curl "http://localhost:8000/analyze/demo?wetlands_buffer=50&transmission_enabled=false"
```

**Map controls:**
Use the ⚙️ Constraint Layers panel in the sidebar to toggle layers on/off and edit buffer distances, then click **Run Analysis**.

---

## API

| Method | Path | Description |
|---|---|---|
| GET | `/health` | Health check |
| GET | `/config` | Current constraint configuration |
| GET | `/analyze/demo` | Quick demo with query-param overrides |
| POST | `/analyze/parcel` | Full analysis: parcel GeoJSON + overrides + manual edits |
| POST | `/analyze/bbox` | Analysis from a bounding box |

### POST /analyze/parcel

```json
{
  "parcel_geojson": { "type": "Feature", "geometry": {...}, "properties": {} },
  "constraint_overrides": {
    "wetlands": { "buffer_m": 50, "enabled": true },
    "transmission_lines": { "enabled": false }
  },
  "manual_exclusions": [ { "type": "Polygon", "coordinates": [...] } ],
  "manual_additions":  [ { "type": "Polygon", "coordinates": [...] } ]
}
```

### Response

```json
{
  "total_acres": 142,
  "buildable_acres": 89,
  "removed_acres": 53,
  "utilization_pct": 62.7,
  "breakdown": [
    {
      "layer": "wetlands",
      "label": "Wetlands (NWI)",
      "buffer_m": 30,
      "removed_acres": 18,
      "color": "#1a9850",
      "note": "NWI wetland polygons + 30m buffer (EPA §404 guidance)"
    }
  ],
  "buildable_geojson": { ... },
  "constraint_layers": { "wetlands": { ... }, "flood_zone": { ... } },
  "active_constraints": { "wetlands": { "buffer_m": 30, "enabled": true }, ... }
}
```

---

## Grading harness notes

Per spec:
- All areas computed in **EPSG:3857** (Web Mercator) using planar area formula
- Final buildable acreage rounded **up** to nearest whole acre (`math.ceil`)
- Comment `// grading-key: HELIOS-4827` placed directly above the area-calculation function in `main.py`

---

## Data sources

| Dataset | URL | Format | License |
|---|---|---|---|
| NWI Wetlands | https://www.fws.gov/program/national-wetlands-inventory | ArcGIS REST | Public domain |
| FEMA NFIP Flood Zones | https://hazards.fema.gov/arcgis/rest/services/public/NFHL | ArcGIS REST | Public domain |
| HIFLD Transmission Lines | https://hifld-geoplatform.opendata.arcgis.com | ArcGIS REST | Open / CC0 |
| OSM Buildings | https://overpass-api.de | Overpass API | ODbL |
| Base map tiles | https://tile.openstreetmap.org | XYZ raster | ODbL |

---

## Stack

| Component | Technology | Why |
|---|---|---|
| Backend | Python / FastAPI | Fast async HTTP; GeoPandas + Shapely for geometry |
| Geometry engine | GeoPandas + Shapely | Best-in-class polygon ops in Python; handles real-world geometry messiness |
| Frontend | React 18 | Component model suits the sidebar/map split |
| Map | MapLibre GL JS | Open-source, vector tiles, draw support via MapboxDraw |
| Drawing | @mapbox/mapbox-gl-draw | Production-quality polygon draw/edit on MapLibre |

---

## Performance

| Data size | Behaviour |
|---|---|
| Single parcel, 1 county | < 2 s including API round-trips |
| Entire county (~50k parcels) | Backend geometry ops: ~10–30 s; bottleneck is unary_union across many features |
| Multi-county / state-wide | Would strain: move to PostGIS + ST_Intersection for DB-side spatial ops |

**Where it would break:**
1. Large NWI or flood-zone datasets (>100 k polygons) — `unary_union` is O(n log n) but memory-bound in Python
2. Concurrent requests — uvicorn is async but GeoPandas ops are GIL-bound; add a process pool or use a spatial DB
3. Parcel-level batch analysis — currently one parcel per request; add a batch endpoint with streaming response

**What I'd do next:**
- Store constraint layers in PostGIS, run `ST_Intersection` server-side
- Cache fetched constraint tiles by bbox + timestamp
- Add a tile server for constraint layers (MBTiles) so the map renders at any zoom
- Support TNRIS parcel shapefile upload directly

---

## Approach writeup

See `APPROACH.md`.
