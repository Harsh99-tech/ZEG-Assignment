import React, { useEffect, useRef, useState, useCallback } from 'react';
import maplibregl from 'maplibre-gl';
import MapboxDraw from '@mapbox/mapbox-gl-draw';
import axios from 'axios';
import 'maplibre-gl/dist/maplibre-gl.css';
import '@mapbox/mapbox-gl-draw/dist/mapbox-gl-draw.css';
import './App.css';

const API = process.env.REACT_APP_API_URL || 'http://localhost:8000';

// Default Travis County demo bbox (downtown Austin area)
const DEMO_BBOX = {
  min_lon: -97.78, min_lat: 30.24,
  max_lon: -97.70, max_lat: 30.30,
};

const CONSTRAINT_META = {
  wetlands:           { label: 'Wetlands (NWI)',              color: '#1a9850', icon: '🌿' },
  flood_zone:         { label: 'FEMA 100-yr Floodplain',      color: '#4393c3', icon: '🌊' },
  transmission_lines: { label: 'Transmission Lines',          color: '#d6604d', icon: '⚡' },
  buildings:          { label: 'Existing Buildings',          color: '#f4a582', icon: '🏗️' },
  manual_exclusion:   { label: 'Manual Exclusions',           color: '#b2182b', icon: '✂️' },
  manual_addition:    { label: 'Manual Additions',            color: '#2ca25f', icon: '➕' },
};

function formatAcres(n) {
  return n == null ? '—' : `${Number(n).toLocaleString()} ac`;
}

// ── Sidebar panel ──────────────────────────────────────────────────────────────
function Sidebar({ result, config, overrides, setOverrides, drawMode, setDrawMode, onAnalyze, loading, error, manualPolygons }) {
  const [collapsed, setCollapsed] = useState({});

  const toggle = (k) => setCollapsed(p => ({ ...p, [k]: !p[k] }));

  const updateBuffer = (key, val) => {
    setOverrides(p => ({
      ...p,
      [key]: { ...p[key], buffer_m: val === '' ? null : Number(val) },
    }));
  };

  const updateEnabled = (key, val) => {
    setOverrides(p => ({
      ...p,
      [key]: { ...p[key], enabled: val },
    }));
  };

  return (
    <aside className="sidebar">
      <div className="sidebar-header">
        <div className="logo-mark">◈</div>
        <div>
          <h1>Buildable Land</h1>
          <p className="subtitle">Constraint Analysis</p>
        </div>
      </div>

      {/* Quick-run bar */}
      <div className="quick-run">
        <button
          className={`btn-primary ${loading ? 'loading' : ''}`}
          onClick={onAnalyze}
          disabled={loading}
        >
          {loading ? <span className="spinner" /> : '▶'}
          {loading ? 'Analyzing…' : 'Run Analysis'}
        </button>
      </div>

      {error && <div className="error-banner">{error}</div>}

      {/* Results summary */}
      {result && (
        <div className="results-summary">
          <div className="metric-row">
            <div className="metric">
              <span className="metric-val">{formatAcres(result.total_acres)}</span>
              <span className="metric-lbl">Total Parcel</span>
            </div>
            <div className="metric accent">
              <span className="metric-val">{formatAcres(result.buildable_acres)}</span>
              <span className="metric-lbl">Buildable</span>
            </div>
            <div className="metric muted">
              <span className="metric-val">{result.utilization_pct}%</span>
              <span className="metric-lbl">Usable</span>
            </div>
          </div>

          {/* Breakdown */}
          <div className="breakdown-title">What was removed</div>
          {result.breakdown.length === 0 && (
            <div className="no-constraints">No constraints intersected this parcel.</div>
          )}
          {result.breakdown.map((b, i) => {
            const meta = CONSTRAINT_META[b.layer] || {};
            const isAdd = b.removed_acres < 0;
            return (
              <div key={i} className="breakdown-row">
                <span className="dot" style={{ background: b.color || meta.color }} />
                <div className="breakdown-info">
                  <div className="breakdown-label">{meta.icon} {b.label}</div>
                  <div className="breakdown-note">{b.note}</div>
                </div>
                <span className={`breakdown-acres ${isAdd ? 'positive' : 'negative'}`}>
                  {isAdd ? '+' : '-'}{formatAcres(Math.abs(b.removed_acres))}
                </span>
              </div>
            );
          })}

          <div className="net-row">
            <span>Net buildable</span>
            <strong>{formatAcres(result.buildable_acres)}</strong>
          </div>
        </div>
      )}

      {/* Constraint controls */}
      <div className="section-title" onClick={() => toggle('constraints')} style={{ cursor: 'pointer' }}>
        ⚙️ Constraint Layers
        <span className="chevron">{collapsed.constraints ? '▸' : '▾'}</span>
      </div>

      {!collapsed.constraints && config && (
        <div className="constraint-controls">
          {Object.entries(config.constraints).map(([key, cfg]) => {
            const ov = overrides[key] || {};
            const enabled = ov.enabled !== undefined ? ov.enabled : cfg.enabled;
            const bufVal = ov.buffer_m !== undefined && ov.buffer_m !== null ? ov.buffer_m : cfg.buffer_m;
            const meta = CONSTRAINT_META[key] || {};
            return (
              <div key={key} className={`constraint-row ${!enabled ? 'disabled' : ''}`}>
                <label className="toggle">
                  <input
                    type="checkbox"
                    checked={enabled}
                    onChange={e => updateEnabled(key, e.target.checked)}
                  />
                  <span className="toggle-slider" />
                </label>
                <span className="dot" style={{ background: cfg.color }} />
                <span className="constraint-label">{meta.icon} {cfg.label}</span>
                <div className="buffer-input-wrap">
                  <input
                    type="number"
                    min="0"
                    max="500"
                    value={bufVal}
                    disabled={!enabled}
                    onChange={e => updateBuffer(key, e.target.value)}
                    className="buffer-input"
                  />
                  <span className="buffer-unit">m</span>
                </div>
              </div>
            );
          })}
          <p className="config-hint">Edit <code>config.yaml</code> to change defaults permanently.</p>
        </div>
      )}

      {/* Draw tools */}
      <div className="section-title" onClick={() => toggle('draw')} style={{ cursor: 'pointer' }}>
        ✏️ Manual Edit
        <span className="chevron">{collapsed.draw ? '▸' : '▾'}</span>
      </div>

      {!collapsed.draw && (
        <div className="draw-controls">
          <p className="draw-hint">Draw polygons on the map to carve out or restore land.</p>
          <div className="draw-buttons">
            <button
              className={`draw-btn carve ${drawMode === 'exclude' ? 'active' : ''}`}
              onClick={() => setDrawMode(drawMode === 'exclude' ? null : 'exclude')}
            >
              ✂️ Carve Out
            </button>
            <button
              className={`draw-btn restore ${drawMode === 'include' ? 'active' : ''}`}
              onClick={() => setDrawMode(drawMode === 'include' ? null : 'include')}
            >
              ➕ Restore
            </button>
          </div>
          {drawMode && (
            <p className="draw-active-hint">
              {drawMode === 'exclude'
                ? '⚠️ Click to draw exclusion polygon'
                : '✅ Click to draw restoration polygon'}
              <br />
              <small>Double-click to finish. Then click Run Analysis.</small>
            </p>
          )}
          {manualPolygons.exclusions.length > 0 && (
            <div className="polygon-count">✂️ {manualPolygons.exclusions.length} carve-out(s)</div>
          )}
          {manualPolygons.inclusions.length > 0 && (
            <div className="polygon-count restore">➕ {manualPolygons.inclusions.length} restore area(s)</div>
          )}
        </div>
      )}

      <div className="sidebar-footer">
        <span>CRS: EPSG:3857 (planar)</span>
        <span>Travis County, TX demo</span>
      </div>
    </aside>
  );
}

// ── Map component ──────────────────────────────────────────────────────────────
function Map({ result, onBboxChange, drawMode, onPolygonDrawn, mapRef, drawRef }) {
  const containerRef = useRef(null);
  const [mapReady, setMapReady] = useState(false);

  // Init map
  useEffect(() => {
    if (mapRef.current) return;
    const map = new maplibregl.Map({
      container: containerRef.current,
      style: {
        version: 8,
        sources: {
          'osm': {
            type: 'raster',
            tiles: ['https://tile.openstreetmap.org/{z}/{x}/{y}.png'],
            tileSize: 256,
            attribution: '© OpenStreetMap contributors',
          },
        },
        layers: [{ id: 'osm', type: 'raster', source: 'osm' }],
      },
      center: [-97.74, 30.27],
      zoom: 12,
    });

    map.addControl(new maplibregl.NavigationControl(), 'top-right');
    map.addControl(new maplibregl.ScaleControl(), 'bottom-right');

    // MapboxDraw for polygon editing
    const draw = new MapboxDraw({
      displayControlsDefault: false,
      controls: { polygon: true, trash: true },
    });
    map.addControl(draw, 'top-right');
    drawRef.current = draw;

    map.on('load', () => {
      // Sources for analysis results
      map.addSource('parcel', { type: 'geojson', data: { type: 'FeatureCollection', features: [] } });
      map.addSource('buildable', { type: 'geojson', data: { type: 'FeatureCollection', features: [] } });
      map.addSource('constraints', { type: 'geojson', data: { type: 'FeatureCollection', features: [] } });

      // Parcel outline
      map.addLayer({ id: 'parcel-fill', type: 'fill', source: 'parcel',
        paint: { 'fill-color': '#ffffff', 'fill-opacity': 0.08 } });
      map.addLayer({ id: 'parcel-line', type: 'line', source: 'parcel',
        paint: { 'line-color': '#ffffff', 'line-width': 2.5, 'line-dasharray': [4, 2] } });

      // Constraint areas
      map.addLayer({ id: 'constraints-fill', type: 'fill', source: 'constraints',
        paint: {
          'fill-color': ['get', 'color'],
          'fill-opacity': 0.45,
        }
      });
      map.addLayer({ id: 'constraints-line', type: 'line', source: 'constraints',
        paint: { 'line-color': ['get', 'color'], 'line-width': 1.2 } });

      // Buildable (green)
      map.addLayer({ id: 'buildable-fill', type: 'fill', source: 'buildable',
        paint: { 'fill-color': '#00e676', 'fill-opacity': 0.35 } });
      map.addLayer({ id: 'buildable-line', type: 'line', source: 'buildable',
        paint: { 'line-color': '#00e676', 'line-width': 2 } });

      setMapReady(true);
    });

    // Capture bbox on moveend
    map.on('moveend', () => {
      const bounds = map.getBounds();
      onBboxChange({
        min_lon: bounds.getWest(),
        min_lat: bounds.getSouth(),
        max_lon: bounds.getEast(),
        max_lat: bounds.getNorth(),
      });
    });

    mapRef.current = map;

    return () => {
      map.remove();
      mapRef.current = null;
    };
  }, []);

  // Handle draw mode changes
  useEffect(() => {
    if (!drawRef.current) return;
    if (drawMode === 'exclude' || drawMode === 'include') {
      drawRef.current.changeMode('draw_polygon');
    } else {
      drawRef.current.changeMode('simple_select');
    }
  }, [drawMode]);

  // Listen for completed polygons
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapReady) return;

    const handler = (e) => {
      if (e.features && e.features.length > 0) {
        onPolygonDrawn(e.features[0].geometry, drawMode);
      }
    };
    map.on('draw.create', handler);
    return () => map.off('draw.create', handler);
  }, [mapReady, drawMode, onPolygonDrawn]);

  // Update map layers when result changes
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapReady || !result) return;

    // Parcel = bounding box of the analysis area (we use a big bbox polygon)
    const bbox = result._bbox;
    if (bbox) {
      const parcelFeature = {
        type: 'Feature',
        geometry: {
          type: 'Polygon',
          coordinates: [[
            [bbox.min_lon, bbox.min_lat],
            [bbox.max_lon, bbox.min_lat],
            [bbox.max_lon, bbox.max_lat],
            [bbox.min_lon, bbox.max_lat],
            [bbox.min_lon, bbox.min_lat],
          ]],
        },
        properties: {},
      };
      map.getSource('parcel').setData({ type: 'FeatureCollection', features: [parcelFeature] });
    }

    // Buildable area
    if (result.buildable_geojson) {
      const buildableFeature = {
        type: 'Feature',
        geometry: result.buildable_geojson,
        properties: {},
      };
      map.getSource('buildable').setData({ type: 'FeatureCollection', features: [buildableFeature] });
    }

    // Constraint layers with colors
    const constraintFeatures = [];
    Object.entries(result.constraint_layers || {}).forEach(([key, geom]) => {
      const meta = CONSTRAINT_META[key] || {};
      if (geom) {
        constraintFeatures.push({
          type: 'Feature',
          geometry: geom,
          properties: { color: meta.color || '#999', label: meta.label || key },
        });
      }
    });
    map.getSource('constraints').setData({ type: 'FeatureCollection', features: constraintFeatures });

    // Fit to parcel
    if (bbox) {
      map.fitBounds(
        [[bbox.min_lon, bbox.min_lat], [bbox.max_lon, bbox.max_lat]],
        { padding: 60, duration: 800 }
      );
    }
  }, [result, mapReady]);

  return (
    <div className="map-container">
      <div ref={containerRef} className="map" />
      <div className="map-legend">
        <div className="legend-row"><span className="legend-swatch buildable" />Buildable</div>
        {Object.entries(CONSTRAINT_META).slice(0, 4).map(([k, v]) => (
          <div key={k} className="legend-row">
            <span className="legend-swatch" style={{ background: v.color }} />
            {v.label}
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Root App ───────────────────────────────────────────────────────────────────
export default function App() {
  const mapRef = useRef(null);
  const drawRef = useRef(null);

  const [config, setConfig] = useState(null);
  const [overrides, setOverrides] = useState({});
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [drawMode, setDrawMode] = useState(null);
  const [currentBbox, setCurrentBbox] = useState(DEMO_BBOX);
  const [manualPolygons, setManualPolygons] = useState({ exclusions: [], inclusions: [] });

  // Load config on mount
  useEffect(() => {
    axios.get(`${API}/config`).then(r => setConfig(r.data)).catch(console.error);
  }, []);

  const handlePolygonDrawn = useCallback((geometry, mode) => {
    setManualPolygons(prev => {
      if (mode === 'exclude') {
        return { ...prev, exclusions: [...prev.exclusions, geometry] };
      } else if (mode === 'include') {
        return { ...prev, inclusions: [...prev.inclusions, geometry] };
      }
      return prev;
    });
    setDrawMode(null);
  }, []);

  const handleAnalyze = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const bbox = currentBbox;
      const params = new URLSearchParams({
        min_lon: bbox.min_lon,
        min_lat: bbox.min_lat,
        max_lon: bbox.max_lon,
        max_lat: bbox.max_lat,
      });

      // Pass per-layer overrides as flat query params
      Object.entries(overrides).forEach(([key, ov]) => {
        if (ov.buffer_m !== null && ov.buffer_m !== undefined) {
          params.set(`${key}_buffer`, ov.buffer_m);
        }
        if (ov.enabled !== undefined) {
          params.set(`${key}_enabled`, ov.enabled);
        }
      });

      // Use POST /analyze/parcel for full control
      const body = {
        parcel_geojson: {
          type: 'Feature',
          geometry: {
            type: 'Polygon',
            coordinates: [[
              [bbox.min_lon, bbox.min_lat],
              [bbox.max_lon, bbox.min_lat],
              [bbox.max_lon, bbox.max_lat],
              [bbox.min_lon, bbox.max_lat],
              [bbox.min_lon, bbox.min_lat],
            ]],
          },
          properties: {},
        },
        constraint_overrides: Object.fromEntries(
          Object.entries(overrides).map(([k, v]) => [k, {
            buffer_m: v.buffer_m ?? null,
            enabled: v.enabled ?? null,
          }])
        ),
        manual_exclusions: manualPolygons.exclusions,
        manual_additions: manualPolygons.inclusions,
      };

      const res = await axios.post(`${API}/analyze/parcel`, body);
      setResult({ ...res.data, _bbox: bbox });
    } catch (e) {
      setError(e.response?.data?.detail || e.message || 'Analysis failed');
    } finally {
      setLoading(false);
    }
  }, [currentBbox, overrides, manualPolygons]);

  // Run demo analysis on first load
  useEffect(() => {
    if (config) handleAnalyze();
  }, [config]); // eslint-disable-line

  return (
    <div className="app">
      <Sidebar
        result={result}
        config={config}
        overrides={overrides}
        setOverrides={setOverrides}
        drawMode={drawMode}
        setDrawMode={setDrawMode}
        onAnalyze={handleAnalyze}
        loading={loading}
        error={error}
        manualPolygons={manualPolygons}
      />
      <Map
        result={result}
        onBboxChange={setCurrentBbox}
        drawMode={drawMode}
        onPolygonDrawn={handlePolygonDrawn}
        mapRef={mapRef}
        drawRef={drawRef}
      />
    </div>
  );
}
